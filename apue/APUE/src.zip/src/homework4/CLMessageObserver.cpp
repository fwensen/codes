#include "CLMessageObserver.h"

CLMessageObserver::CLMessageObserver()
{
}

CLMessageObserver::~CLMessageObserver()
{
}