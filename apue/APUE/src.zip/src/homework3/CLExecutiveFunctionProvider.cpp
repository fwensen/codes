#include "CLExecutiveFunctionProvider.h"

CLExecutiveFunctionProvider::CLExecutiveFunctionProvider()
{
}

CLExecutiveFunctionProvider::~CLExecutiveFunctionProvider()
{
}
